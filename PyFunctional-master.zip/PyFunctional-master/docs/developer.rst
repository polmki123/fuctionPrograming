Developer Documentation
=======================

functional.streams
------------------

.. automodule:: functional.streams
    :members:
    :private-members:
    :special-members:
    :undoc-members:
    :show-inheritance:

functional.pipeline
-------------------

.. automodule:: functional.pipeline
    :members:
    :private-members:
    :special-members:
    :undoc-members:
    :show-inheritance:

functional.lineage
------------------

.. automodule:: functional.lineage
    :members:
    :private-members:
    :special-members:
    :undoc-members:
    :show-inheritance:

functional.transformations
--------------------------

.. automodule:: functional.transformations
    :members:
    :private-members:
    :special-members:
    :undoc-members:
    :show-inheritance:

functional.util
---------------

.. automodule:: functional.util
    :members:
    :private-members:
    :special-members:
    :undoc-members:
    :show-inheritance:
